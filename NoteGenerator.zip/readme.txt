Notes Generation App for Work Orders


The Notes Generation App is a web application that allows you to create and copy notes with specific information such as date, time, tower and distance. The application is built using HTML and JavaScript, and can be accessed from any device with a web browser.

The purpose of this app is to standardize note entries in ceres opps and work orders, reducing chances of errors or miscommunication.



To use the Notes Generation App, simply open the app in your web browser by clicking on index.html and start creating notes. Follow these steps to create a note:

Select date/time to add the current date and time to your note.
Choose the Plan from dropdown menu
Select the tower and enter the distance in the respective fields. Click on add fields button for additional space to add towers
Add any promos to notes
Write your notes in the text area provided.
Choose term of the pan
Select any special options such as bring 32ft ladder
Click submit to generate note
Click copy to clipboard button to copy generated note
